__all__ = ['visualizations', 'collection_from_db',
          'collection_no_db', 'create_db']